// Typedefs for structs
typedef struct node node;

typedef struct node{
    int n;
    float x;
    float y;
    float z;
    float w;
    node * next;
} node;